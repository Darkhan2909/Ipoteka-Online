$(document).ready(function () {


    //SCRIPTS FOR SELECT/OPTIONS


    var x, i, j, l, ll, selElmnt, a, b, c, z;
    /* Look for any elements with the class "custom-select": */
    x = document.getElementsByClassName("custom-select--for--counts");
    z = document.getElementsByClassName("custom-select");
    l = x.length;
    for (i = 0; i < l; i++) {
        selElmnt = x[i].getElementsByTagName("select")[0];
        ll = selElmnt.length;
        /* For each element, create a new DIV that will act as the selected item: */
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
        x[i].appendChild(a);
        /* For each element, create a new DIV that will contain the option list: */
        b = document.createElement("DIV");
        n = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");
        var counter = 1;
        var bankAccountInquiry = 20;
        for (j = 1; j < ll; j++) {
            if (j == 1 && type == bankAccountInquiry) {
                c = document.createElement("DIV");


                c.innerHTML = selElmnt.options[j].innerHTML = `<div class="option--for--forms">
                            <div>
                                <h3>${All}</h3>
                                <p>${AllDep}</p>
                            </div>
                            <span></span>
                        </div>`;
                counter = 2;
            }
            else {
                var value = accInfo[Object.keys(accInfo)[(j - counter)]];
                /* For each option in the original select element,
                create a new DIV that will act as an option item: */
                c = document.createElement("DIV");


                c.innerHTML = selElmnt.options[j].innerHTML = `<div class="option--for--forms">
                            <div>
                                <input type='hidden' value="${value.bankAccountType}"/>
                                <h3>${dict[value.bankAccountType]}</h3>
                                <p>${value.accCode}</p>
                            </div>
                            <span>${value.balance} ₸</span>
                        </div>`;
            }
            c.addEventListener("click", function (e) {
                /* When an item is clicked, update the original select box,
                and the selected item: */
                var y, i, k, s, h, sl, yl;
                s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                sl = s.length;
                h = this.parentNode.previousSibling;
                for (i = 0; i < sl; i++) {
                    if (s.options[i].innerHTML == this.innerHTML) {
                        s.selectedIndex = i;
                        h.innerHTML = this.innerHTML;
                        y = this.parentNode.getElementsByClassName("same-as-selected");
                        yl = y.length;
                        for (k = 0; k < yl; k++) {
                            y[k].removeAttribute("class");
                        }
                        this.setAttribute("class", "same-as-selected");
                        break;
                    }
                }
                h.click();
                $('#AccountType').val($(this).find('input').val());
            });
            b.appendChild(c);
        }
        x[i].appendChild(b);
        a.addEventListener("click", function (e) {
            /* When the select box is clicked, close any other select boxes,
            and open/close the current select box: */
            e.stopPropagation();
            closeAllSelect(this);
            this.nextSibling.classList.toggle("select-hide");
            this.classList.toggle("select-arrow-active");
        });
    }
    //i++;

    /* If the user clicks anywhere outside the select box,
    then close all select boxes: */
    document.addEventListener("click", closeAllSelect);


    $(".select-selected").click(function () {
        $(this).parent('.custom-select').find(".select-selected").css('color', '#2C3537');
        $(this).parent('.custom-select').find(".select-items div").css('color', '#2C3537');
    })
    // $(".select-items div").click(function (){
    //     $(this).parent('.select-items').parent('.custom-select').parent('div').parent('.select_blocks').parent('.form_app').find(".btn-form_app").prop('disabled', false);
    // })



    len = z.length;
    for (i = 0; i < len; i++) {
        selElmnt = z[i].getElementsByTagName("select")[0];
        ll = selElmnt.length;
        /* For each element, create a new DIV that will act as the selected item: */
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
        z[i].appendChild(a);
        /* For each element, create a new DIV that will contain the option list: */
        b = document.createElement("DIV");
        n = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");
        for (j = 1; j < ll; j++) {
            /* For each option in the original select element,
            create a new DIV that will act as an option item: */
            c = document.createElement("DIV");
            c.innerHTML = selElmnt.options[j].innerHTML;
            c.addEventListener("click", function (e) {
                /* When an item is clicked, update the original select boz,
                and the selected item: */
                var y, i, k, s, h, sl, yl;
                s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                sl = s.length;
                h = this.parentNode.previousSibling;
                for (i = 0; i < sl; i++) {
                    if (s.options[i].innerHTML == this.innerHTML) {
                        s.selectedIndex = i;
                        h.innerHTML = this.innerHTML;
                        y = this.parentNode.getElementsByClassName("same-as-selected");
                        yl = y.length;
                        for (k = 0; k < yl; k++) {
                            y[k].removeAttribute("class");
                        }
                        this.setAttribute("class", "same-as-selected");
                        break;
                    }
                }
                h.click();
            });
            b.appendChild(c);
        }
        z[i].appendChild(b);
        a.addEventListener("click", function (e) {
            /* When the select boz is clicked, close any other select bozes,
            and open/close the current select boz: */
            e.stopPropagation();
            closeAllSelect(this);
            this.nextSibling.classList.toggle("select-hide");
            this.classList.toggle("select-arrow-active");
        });
    }

    function closeAllSelect(elmnt) {
        /* A function that will close all select bozes in the document,
        ezcept the current select boz: */
        var z, y, i, zl, yl, arrNo = [];
        z = document.getElementsByClassName("select-items");
        y = document.getElementsByClassName("select-selected");
        zl = z.length;
        yl = y.length;
        for (i = 0; i < yl; i++) {
            if (elmnt == y[i]) {
                arrNo.push(i)
            } else {
                y[i].classList.remove("select-arrow-active");
            }
        }
        for (i = 0; i < zl; i++) {
            if (arrNo.indexOf(i)) {
                z[i].classList.add("select-hide");
            }
        }
    }

    // $(".select-items div").click(function (){
    //         if($akimatId.val()>0&& $creditId.val()>0){
    //         $(this).parent('.select-items').parent('.custom-select').parent('div').parent('.select_blocks').parent('.form_app').find(".btn-form_app").prop('disabled', false);
    //         }});



});