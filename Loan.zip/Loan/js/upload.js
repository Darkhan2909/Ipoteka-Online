$(document).ready(function(){
   
    $(document).on('change','.up', function(){
        var id = $(this).attr('id'); /* gets the filepath and filename from the input */
        var profilePicValue = $(this).val();
        var fileNameStart = profilePicValue.lastIndexOf('\\'); /* finds the end of the filepath */
        profilePicValue = profilePicValue.substr(fileNameStart + 1).substring(0,20); /* isolates the filename */
        //var profilePicLabelText = $(".upl"); /* finds the label text */
        if (profilePicValue != '') {
            //console.log($(this).closest('.fileUpload').find('.upl').length);
           $(this).closest('.fileUpload').find('.upl').html(`<p><span class="text--blues">${profilePicValue}</span></p><span><img src="Images/AttachmentBlack.svg" alt="">Изменить</span>`); /* changes the label text */
        }
    });
 
    $(".btn-new").on('click',function(){
         $("#uploader").append(`
         <div class="row uploadDoc">
           <div class="col-sm-3">
             
             <div class="fileUpload btn btn-orange">
               
               <div class="upl" id="upload"><p>.pdf, .jpg</p><span class="text--blues"><img src="Images/Attachment.svg" alt="">Загрузить</span></div>
               <input type="file" class="upload up" id="up"  />
             </div><!-- btn-orange -->
           </div>
           <div class="col-sm-1"><a class="btn-check"><i class="fa fa-times"></i></a></div><!-- col-1 -->
         </div><!--row-->
         `);
    });
     
    $(document).on("click", "a.btn-check" , function() {
      if($(".uploadDoc").length>1){
         $(this).closest(".uploadDoc").remove();
       }else{
         alert("You have to upload at least one document.");
       } 
    });
    var unblocks = true;
    $(".HideShowBlocks").on("click", function(){
        if(unblocks){            
            $(".HideShowBlocks_File").css("display","grid");
            $(".HideShowBlocksTexts").text("Показать")
            unblocks = false;
        }
        else{
            $(".HideShowBlocks_File").css("display","none");
            $(".HideShowBlocksTexts").text("Скрыть")
            unblocks = true;
        
        }
    })
 });