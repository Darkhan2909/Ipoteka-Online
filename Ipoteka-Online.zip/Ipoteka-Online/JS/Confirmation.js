
document.getElementById('vector2-checkbox').onclick=CheckClick;

function CheckClick(){
    if (this.checked){
        this.parentNode.nextElementSibling.disabled = false;
        this.parentNode.nextElementSibling.classList.add('activeted')
    }
    else{
        this.parentNode.nextElementSibling.classList.remove('activeted')
        this.parentNode.nextElementSibling.disabled = true;
    }
}