// OPTIONAL JS

var arrowdown = true;
$("button#dropdownMenuButton").on('click', function(){
    if(arrowdown){
        $(this).find(".ArrowDown").css("transform","rotate(180deg)");
        arrowdown = false;
    }
    else{
        $(this).find(".ArrowDown").css("transform","rotate(0deg)");
        arrowdown = true;
    }
});
// Change the button text & add active class
$('.jRadioDropdown').change(function() {
    var dropdown = $(this).closest('.dropdown');
    var thislabel = $(this).closest('label');

    dropdown.find('label').removeClass('active');
    if( $(this).is(':checked') ) {
        thislabel.addClass('active');
        dropdown.find('#dropdownMenuButton span').html( thislabel.text() );
        $(".ArrowDown").css("transform","rotate(0deg)");
        arrowdown = true;
        $(".block-for-none").removeClass("none");
    }

});
$(window).click(function() {
    //Hide the menus if visible
    $(".ArrowDown").css("transform","rotate(0deg)");
    arrowdown = true;
});
//Add tabindex on labels
$('label.dropdown-item').each(function (index, value){
    $(this).attr('tabindex', 0 );
    $(this).find('input').attr('tabindex', -1 );
});

//Add keyboard navigation
$('label.dropdown-item').keypress(function(e){
    if((e.keyCode ? e.keyCode : e.which) == 13){
        $(this).trigger('click');
    }
});