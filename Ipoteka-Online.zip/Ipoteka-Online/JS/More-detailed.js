$(".property_insurance--more").unbind('click').bind('click',more)
$(".application_property--more").unbind('click').bind('click',more)
$(".seller_details--more").unbind('click').bind('click',more);
$(".documents_for_download--more").unbind('click').bind('click',more);



function more(){
    var blocks = this.parentElement.nextElementSibling.classList.contains('none-more');
    if(!blocks){

        this.getElementsByTagName('p')[0].innerHTML = 'Подробнее';
        this.parentElement.nextElementSibling.classList.add('none-more');
    }
    else{
        this.getElementsByTagName('p')[0].innerHTML = 'Скрыть';
        this.parentElement.nextElementSibling.classList.remove('none-more');
    }
}