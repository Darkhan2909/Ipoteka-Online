$(".Request-evaluation-button--more").unbind('click').bind('click',more);

function more(){
    var blocks = this.parentElement.nextElementSibling.classList.contains('none-more');
    if(!blocks){

        this.getElementsByTagName('p')[0].innerHTML = 'Подробнее';
        this.parentElement.nextElementSibling.classList.add('none-more');
    }
    else{
        this.getElementsByTagName('p')[0].innerHTML = 'Скрыть';
        this.parentElement.nextElementSibling.classList.remove('none-more');
    }
}