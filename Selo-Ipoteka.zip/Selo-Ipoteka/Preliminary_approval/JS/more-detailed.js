
$(".button_type--simples").unbind('click').bind('click', function(){
    var blocks = this.parentElement.nextElementSibling.classList.contains('d-none');

    if(!blocks){
        this.parentElement.nextElementSibling.classList.add('d-none');
    }
    else{
        this.parentElement.nextElementSibling.classList.remove('d-none');
    }
})